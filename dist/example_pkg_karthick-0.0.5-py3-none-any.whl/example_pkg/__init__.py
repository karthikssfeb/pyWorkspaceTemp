# from example_pkg import simple_math
# import simple_math
from .simple_math import add, sub, mul, div
__all__ = ["simple_math"]
__version__ = "1.0.0"