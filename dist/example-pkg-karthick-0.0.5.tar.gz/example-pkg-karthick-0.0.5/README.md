# pyWorkspaceTemp
Template to start a python workspace with vscode
